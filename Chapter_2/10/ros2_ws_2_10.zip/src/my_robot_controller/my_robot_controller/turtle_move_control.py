import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist
from turtlesim.msg import Pose

class TurtleMoveControl(Node):
    def __init__(self):
        super().__init__("turtle_move_control")
        
        # 1. 직전 수신 메시지와 비교하여 중복 연산을 방지하기 위한 상태 저장 변수
        self.pose_msg = Pose()
        
        # 2. 속도 제어 명령을 보낼 퍼블리셔 객체 생성
        self.cmd_vel_publisher = self.create_publisher(Twist, "/turtle1/cmd_vel", 10)
        
        # 3. 실시간 위치 피드백을 수신할 서브스크라이버 객체 생성 (타이머 없음)
        self.turtle_pose_subscriber = self.create_subscription(
            Pose, 
            '/turtle1/pose', 
            self.get_turtle_pose, 
            10
        )

    def get_turtle_pose(self, msg):
        # 4. 시뮬레이터로부터 새로운 위치 값이 수신되었고, 기존 값과 변화가 있을 때만 루프 작동
        if msg != self.pose_msg:
            new_cmd_vel = Twist()
            
            # 5. 안전 여유 마진(2.0 ~ 8.0)을 기반으로 한 벽 충돌 회피 임계값 조건문
            if msg.x > 8.0 or msg.x < 2.0 or msg.y > 8.0 or msg.y < 2.0:
                # 위험 구역: 전진 선속도와 회전 각속도를 동시에 주어 곡선 궤적으로 회피
                new_cmd_vel.linear.x = 1.0
                new_cmd_vel.angular.z = 1.0
            else:
                # 안전 구역: 회전 각속도를 0으로 만들어 직진 기동 수행
                new_cmd_vel.linear.x = 1.0
                new_cmd_vel.angular.z = 0.0
                
            # 6. 연산된 피드백 속도 명령을 토픽 채널에 즉시 게시
            self.cmd_vel_publisher.publish(new_cmd_vel)
            
            # 7. 상태 변수 최신화
            self.pose_msg = msg

def main(args=None):
    rclpy.init(args=args)
    turtle_move_control_node = TurtleMoveControl()
    rclpy.spin(turtle_move_control_node)
    rclpy.shutdown()

if __name__ == '__main__':
    main()