import rclpy
from rclpy.node import Node

class LoggingNode(Node):
    def __init__(self):
        super().__init__('timer_node')
        # 상태를 저장하고 두 콜백 함수가 공유할 클래스 속성(인스턴스 변수) 초기화
        self.counter = 0 
        
        # 2초마다 호출될 타이머와 3초마다 호출될 타이머 각각 생성
        self.create_timer(2.0, self.two_seconds_callback)
        self.create_timer(3.0, self.three_seconds_callback)

    def two_seconds_callback(self):
        self.counter += 1
        self.get_logger().info(f'2 seconds passed : {self.counter}')

    def three_seconds_callback(self):
        self.counter -= 1
        self.get_logger().info(f'3 seconds passed : {self.counter}')

def main(args=None):
    rclpy.init(args=args)
    node = LoggingNode()
    rclpy.spin(node) # 프로그램이 종료되지 않도록 무한 대기하며 타이머 이벤트 처리
    rclpy.shutdown()

if __name__ == '__main__':
    main()