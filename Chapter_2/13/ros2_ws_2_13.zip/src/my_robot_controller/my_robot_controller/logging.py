#!/usr/bin/env python3
import rclpy
from rclpy.node import Node

class LoggingNode(Node):
    def __init__(self):
        super().__init__('logging_node')
        self.get_logger().info("logging_node")

# 1. 여기가 정확히 'main'이어야 합니다.
def main(args=None):
    rclpy.init(args=args)
    node = LoggingNode()
    rclpy.spin(node)
    rclpy.shutdown()

if __name__ == '__main__':
    # 2. 여기도 'main()'이어야 합니다.
    main()
