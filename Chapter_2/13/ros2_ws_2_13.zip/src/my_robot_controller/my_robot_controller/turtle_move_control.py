import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist
from turtlesim.msg import Pose
from turtlesim.srv import Kill
from std_srvs.srv import Empty

class TurtleMoveControl(Node):
    def __init__(self):
        super().__init__("turtle_move_control")
        self.pose_msg = Pose()
        
        # 1. 기존 퍼블리셔 & 서브스크라이버
        self.cmd_vel_publisher = self.create_publisher(Twist, "/turtle1/cmd_vel", 10)
        self.turtle_pose_subscriber = self.create_subscription(Pose, '/turtle1/pose', self.get_turtle_pose, 10)
        
        # 2. 서비스 클라이언트 생성 (/kill 요청용)
        self.kill_turtle_client = self.create_client(Kill, "/kill")

        # 3. 서비스 서버 생성 (/quit 수신용)
        self.quit_service = self.create_service(Empty, "/quit", self.quit_svr_callback)

    # 거북이 벽 회피 제어 콜백 (2-10과 동일)
    def get_turtle_pose(self, msg):
        if msg != self.pose_msg:
            new_cmd_vel = Twist()
            if msg.x > 8.0 or msg.x < 2.0 or msg.y > 8.0 or msg.y < 2.0:
                new_cmd_vel.linear.x = 1.0
                new_cmd_vel.angular.z = 1.0
            else:
                new_cmd_vel.linear.x = 1.0
                new_cmd_vel.angular.z = 0.0
            self.cmd_vel_publisher.publish(new_cmd_vel)
            self.pose_msg = msg

    # /quit 서비스 요청이 들어왔을 때 실행되는 콜백
    def quit_svr_callback(self, request, response):
        if self.kill_turtle_client.wait_for_service(1):
            kill_request = Kill.Request()
            kill_request.name = "turtle1"
            # 비동기식으로 /kill 서비스 호출
            future = self.kill_turtle_client.call_async(kill_request)
            # 서버 응답이 도착하면 실행될 콜백 등록
            future.add_done_callback(self.kill_turtle_response)
        else:
            self.get_logger().info("turtlesim's /kill service not available")
        return response

    # /kill 응답이 도착했을 때 실행 (예외 발생시켜 노드 종료 유도)
    def kill_turtle_response(self, future):
        try:
            future.result()
        except Exception as e:
            self.get_logger().info(f"Service call failed {e}")
        # 예외를 발생시켜 메인 스레드로 전파
        raise Exception("Turtle killed")

def main(args=None):
    rclpy.init(args=args)
    turtle_move_control_node = TurtleMoveControl()
    
    try:
        # 노드 무한 루프 대기
        rclpy.spin(turtle_move_control_node)
    except Exception as e:
        # 예외 발생 시 에러가 아닌 안전한 INFO 로그 출력
        turtle_move_control_node.get_logger().info(f"Exception in turtle_move_control_node: {e}")
    finally:
        if rclpy.ok():
            rclpy.shutdown()

if __name__ == '__main__':
    main()