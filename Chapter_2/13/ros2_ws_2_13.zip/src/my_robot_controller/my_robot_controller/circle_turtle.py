import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist

class CircleTurtleNode(Node):
    def __init__(self):
        super().__init__("circle_turtle")
        # 1. 퍼블리셔 생성: (메시지 타입, 토픽 이름, 큐(버퍼) 사이즈)
        self.cmd_vel_publisher = self.create_publisher(Twist, "/turtle1/cmd_vel", 10)
        # 2. 0.1초(10Hz)마다 콜백 함수를 실행하는 타이머 생성
        self.timer = self.create_timer(0.1, self.send_round_velocity)

    def send_round_velocity(self):
        # 3. 전송할 Twist 타입의 빈 메시지 객체 생성
        msg = Twist()
        
        # 4. 원을 그리기 위해 선속도(앞으로 가는 속도)와 각속도(도는 속도)를 동시에 부여
        msg.linear.x = 1.0  
        msg.angular.z = 1.0 
        
        # 5. 완성된 메시지를 토픽에 게시
        self.cmd_vel_publisher.publish(msg)

def main(args=None):
    rclpy.init(args=args)
    circle_turtle_node = CircleTurtleNode()
    rclpy.spin(circle_turtle_node)
    rclpy.shutdown()

if __name__ == '__main__':
    main()