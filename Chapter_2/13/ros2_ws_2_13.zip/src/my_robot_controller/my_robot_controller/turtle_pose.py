import rclpy
from rclpy.node import Node
from turtlesim.msg import Pose

class TurtlePoseNode(Node):
    def __init__(self):
        super().__init__('turtle_pose')
        
        # 데이터가 실제로 바뀔 때만 출력하기 위해 이전 값을 저장할 변수 초기화 (처음엔 비교를 위해 None 설정)
        self.last_x = None
        self.last_y = None
        self.last_theta = None
        
        # 서브스크라이버 생성: (메시지 타입, 토픽 이름, 콜백 함수, 큐 사이즈)
        self.turtle_pose_subscriber = self.create_subscription(
            Pose, 
            '/turtle1/pose', 
            self.get_turtle_pose, 
            10
        )

    def get_turtle_pose(self, msg):
        # 값이 처음 들어왔거나, 속도를 제외한 x, y, theta 중 하나라도 값이 변경되었는지 검사
        if (self.last_x != msg.x or 
            self.last_y != msg.y or 
            self.last_theta != msg.theta):
            
            # 조건이 충족될 때만 로그 파일 및 터미널 화면에 기록
            self.get_logger().info(f'x: {msg.x}, y: {msg.y}, theta: {msg.theta}')
            
            # 다음 비교를 위해 현재 값을 이전 값 변수에 저장(갱신)
            self.last_x = msg.x
            self.last_y = msg.y
            self.last_theta = msg.theta

def main(args = None):
    rclpy.init(args = args)
    turtle_pose_node = TurtlePoseNode()
    rclpy.spin(turtle_pose_node)
    rclpy.shutdown()

if __name__ == '__main__':
    main()