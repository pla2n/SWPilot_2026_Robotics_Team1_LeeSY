#!/usr/bin/env python3
from launch import LaunchDescription
from launch_ros.actions import Node

def generate_launch_description():
    return LaunchDescription([
        # 1. turtlesim 패키지의 시뮬레이터 노드 실행 정의
        Node(
            package='turtlesim',
            executable='turtlesim_node',
            name='turtlesim_node',
            output='screen'
        ),
        
        # 2. my_robot_controller 패키지의 벽 회피 제어 노드 실행 정의
        Node(
            package='my_robot_controller',
            executable='turtle_move_control',
            name='turtle_move_control',
            output='screen'
        ),
    ])