from launch import LaunchDescription
from launch_ros.actions import Node

def generate_launch_description():
    return LaunchDescription([
        Node(
            package='turtlesim',
            executable='turtlesim_node',
            name='turtlesim_node',
            output='screen'
        ),
        # 새로 만든 turtle_follow 실행
        Node(
            package='my_robot_controller',
            executable='turtle_follow',
            name='turtle_follow',
            output='screen'
        ),
    ])