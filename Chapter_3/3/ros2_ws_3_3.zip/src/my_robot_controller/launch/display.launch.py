from launch import LaunchDescription
from launch_ros.actions import Node
from ament_index_python.packages import get_package_share_directory
import os

def generate_launch_description():
    package_name = 'my_robot_controller'
    # 패키지 내 URDF 파일 경로 탐색
    urdf_file_path = os.path.join(get_package_share_directory(package_name), 'urdf', 'simple_robot.urdf')

    return LaunchDescription([
        # 1. robot_state_publisher 노드 실행 (URDF 로드)
        Node(
            package='robot_state_publisher',
            executable='robot_state_publisher',
            name='robot_state_publisher',
            output='screen',
            parameters=[{'robot_description': open(urdf_file_path).read()}]
        ),

        # 2. 직접 구현한 상태 퍼블리셔 노드 실행
        Node(
            package=package_name,
            executable='joint_state_publisher',
            name='joint_state_publisher',
            output='screen'
        ),

        # 3. RViz2 시각화 툴 실행 (-d 옵션으로 저장된 환경설정 파일 로드)
        Node(
            package='rviz2',
            executable='rviz2',
            name='rviz2',
            output='screen',
            arguments=['-d', os.path.join(get_package_share_directory(package_name), 'config', 'robot_display.rviz')]
        ),
    ])
