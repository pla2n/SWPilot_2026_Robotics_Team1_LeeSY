import os
from glob import glob
from setuptools import find_packages, setup

package_name = 'my_robot_controller'

setup(
    name=package_name,
    version='0.0.0',
    packages=find_packages(exclude=['test']),
    data_files=[
        ('share/ament_index/resource_index/packages',
            ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
        (os.path.join('share', package_name, 'launch'), glob('launch/*.launch.py')),
        (
            os.path.join('share', package_name, 'launch'),
            glob('launch/*.launch.py'),
        ),
        (os.path.join('share', package_name, 'urdf'), glob('urdf/*.urdf')),
        (os.path.join('share', package_name, 'config'), glob('config/*.rviz')),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='lee',
    maintainer_email='lee@todo.todo',
    description='TODO: Package description',
    license='TODO: License declaration',
    extras_require={
        'test': [
            'pytest',
        ],
    },
    entry_points={
        'console_scripts': [
        	'logging_node = my_robot_controller.my_logging:main',
        	'timer_node = my_robot_controller.timer_test:main',
        	'circle_turtle = my_robot_controller.circle_turtle:main',
        	'turtle_pose = my_robot_controller.turtle_pose:main',
        	'turtle_move_control = my_robot_controller.turtle_move_control:main',
        	'turtle_follow = my_robot_controller.turtle_follow:main',
        	'joint_state_publisher = my_robot_controller.joint_state_publisher:main',
        ],
    },
)
