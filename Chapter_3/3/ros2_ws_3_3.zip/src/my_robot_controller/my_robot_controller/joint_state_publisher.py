import rclpy
from rclpy.node import Node
from sensor_msgs.msg import JointState

class JointStatePublisher(Node):
    def __init__(self):
        super().__init__('joint_state_publisher')
        # /joint_states 토픽으로 JointState 타입의 메시지를 발행하는 퍼블리셔 생성
        self.publisher_ = self.create_publisher(JointState, '/joint_states', 10)
        # 0.1초(10Hz)마다 상태를 발행하는 타이머 콜백 설정
        self.timer = self.create_timer(0.1, self.publish_joint_states)

        # 초기 위치 및 속도 설정 (임의의 구동 상태 시뮬레이션)
        self.joint_position = 0.0
        self.joint_velocity = 0.1

    def publish_joint_states(self):
        msg = JointState()
        # 현재 시간을 메시지 헤더에 기록 (TF 동기화에 필수)
        msg.header.stamp = self.get_clock().now().to_msg()
        # URDF에 정의된 조인트 이름과 1:1 매칭
        msg.name = ['left_wheel_joint', 'right_wheel_joint']
        
        # 현재 위치와 속도 입력 (우측 바퀴는 대칭 동작을 위해 -값 적용)
        msg.position = [self.joint_position, -self.joint_position]
        msg.velocity = [self.joint_velocity, -self.joint_velocity]
        msg.effort = [0.0, 0.0] # 가해지는 물리적 힘 (본 실습에서는 생략)

        # 다음 발행 주기를 위해 각도(위치) 값 업데이트 누적
        self.joint_position += self.joint_velocity * 0.1
        self.publisher_.publish(msg)

def main(args=None):
    rclpy.init(args=args)
    node = JointStatePublisher()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
